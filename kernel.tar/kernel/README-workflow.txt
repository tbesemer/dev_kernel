===
Overview:

The Kernel used for development is maintained in github.  This Kernel
is a replication of the Kernel that is used within Yocto.  There may
be several "active" Kernels at a time; the Makefile specifies the current
Kernel.

The purpose of using github to host the development Kernel is to allow
localized branches and commits.  For safety, you are free to push to the
upstream origin.  None of this affects the mainline build.

The Makefile has a "help" function:

Targets:
 
 tree_pull:    Pull the Kernel Development Tree
 hard_clean:   Fully destructive clean; wipes out Kernel
 clean:        Gentle clean; removes objects, Kernel Clean
 mrproper:     mrproper on Kernel
 defconfig:    Sets Default Configuration
 xconfig:      Does xconfig on Kernel
 save_config:  Saves current configuration
 vmlinux:      Build Kernel
 modules:      Build Modules
 all:          Build Kernel and Modules
 patchset:     Generate a Patchset of changes
 
General workflow contained in <README-workflow.txt>
 
====
General Work Flow:

 1. 'make tree_pull'  This fetches the tree local.
 2. Get your environment setup by executing bin ~/bin/yocto_env.sh
 3. 'cd dev_kernel; git checkout -b "my bramch"  For example:
        git checkout -b frank_router_test
 4. Perform updates, and do periodic commits through 'git commit'
    to ensure your work is safe.  Test on target.  How to deploy
    outside scope of this README.  If you want to make sure your
    work is backed up, push it back up.  Typical:
       'cd dev_kernel; git commit; git push origin framk_router_test'
 5. When done, generate a patchset through 'make patchset'.  Commit
    to your local branch.


====
Branch and Patch Set Management:

As each component/functional change is done to Kernel, and the branches
are committed and pushed upstream to the origin, the branches will be
merged into master.  Then, an integrated Patch Set will be generated and
installed into the Silver Peak Meta Layer for production builds.

This will be a manual process for now; as each person commits and pushes
to the upstream feed, the branches for each user will be merged into a 
development branch by the OS Master, and then a Patch Set will be generated.

The concept of branching is important, as the automatic Patch Set generation
happens from Master.  For example:

From d768352e9f82822fdc5d4285b6d194b23329da30 Mon Sep 17 00:00:00 2001
From: Thomas Besemer <tbesemer@gmail.com>
Date: Sun, 12 Jun 2016 12:45:20 -0700
Subject: [PATCH 1/2] Testing

---
 generic_x86_64_4.4.12/tom_patch_test.txt | 2 ++
 1 file changed, 2 insertions(+)

diff --git a/generic_x86_64_4.4.12/tom_patch_test.txt b/generic_x86_64_4.4.12/tom_patch_test.txt
index b155829..d06f904 100644
--- a/generic_x86_64_4.4.12/tom_patch_test.txt
+++ b/generic_x86_64_4.4.12/tom_patch_test.txt
@@ -1,3 +1,5 @@
 Just checking automated patch set generation.
 
 Add second commit
+
+Anding branch check.
-- 
1.9.1


From bc7267eb51df1ada2a814bd23052f2dc90b9eae7 Mon Sep 17 00:00:00 2001
From: Thomas Besemer <tbesemer@gmail.com>
Date: Sun, 12 Jun 2016 12:45:57 -0700
Subject: [PATCH 2/2] Ongoin

---
 generic_x86_64_4.4.12/tom_patch_test.txt | 4 +++-
 1 file changed, 3 insertions(+), 1 deletion(-)

diff --git a/generic_x86_64_4.4.12/tom_patch_test.txt b/generic_x86_64_4.4.12/tom_patch_test.txt
index d06f904..0470396 100644
--- a/generic_x86_64_4.4.12/tom_patch_test.txt
+++ b/generic_x86_64_4.4.12/tom_patch_test.txt
@@ -2,4 +2,6 @@ Just checking automated patch set generation.
 
 Add second commit
 
-Anding branch check.
+Adding branch check.
+
+Now adding second addition.
-- 
1.9.1

This showed that a patch was generated from Master on current branch.

